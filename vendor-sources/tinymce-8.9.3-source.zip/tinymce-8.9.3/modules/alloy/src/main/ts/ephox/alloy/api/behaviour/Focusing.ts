import * as ActiveFocus from '../../behaviour/focusing/ActiveFocus';
import * as FocusApis from '../../behaviour/focusing/FocusApis';
import type { FocusingBehaviour } from '../../behaviour/focusing/FocusingTypes';
import FocusSchema from '../../behaviour/focusing/FocusSchema';

import * as Behaviour from './Behaviour';

const Focusing: FocusingBehaviour = Behaviour.create({
  fields: FocusSchema,
  name: 'focusing',
  active: ActiveFocus,
  apis: FocusApis
  // Consider adding isFocused an an extra
});

export {
  Focusing
};
